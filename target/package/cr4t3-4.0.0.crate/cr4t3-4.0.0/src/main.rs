fn main() {
  println!("Welcome to my program of converting Fahrenheit to Celcius!!!\n");
}